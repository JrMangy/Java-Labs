package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.demo.domain.CarInfo;
import com.example.demo.domain.CarRepository;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoApplication {
    private static final Logger log = LoggerFactory.getLogger(DemoApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(CarRepository repository) {
        return args -> {
            //save a couple customers
            repository.save(new CarInfo("Nissan", "Altima"));
            repository.save(new CustomerInfo("Kyle", "Can't Draft"));
            repository.save(new CustomerInfo("Cioce", "The Soprano King"));
            repository.save(new CustomerInfo("Pravin", "The Bearded Loser"));

            //read all customers
            log.info("Customers found with findAll() : ");
            log.info("---------------------------------");
            for (CustomerInfo customer : repository.findAll()) {
                log.info(customer.toString());
            }
            log.info("");

            //read an individual customer by ID
            repository.findById(1L)
                    .ifPresent(customer -> {
                        log.info("Customer found with findById(1L) : ");
                        log.info("-----------------------------------");
                        log.info(customer.toString());
                        log.info("");
                    });
            log.info("Customer found with findByLastName('Can't Draft'):");
            log.info("---------------------------------");
            repository.findByLastName("Can't Draft").forEach(bauer -> {
                log.info(bauer.toString());
            });
        };
    }
}
// Henny, 151 Rum, Cognac, Tennessee Honey,