package com.example.demo.domain;

import java.util.List;
import com.example.demo.domain.CarInfo;

import org.springframework.data.repository.CrudRepository;

public interface CarRepository extends CrudRepository<CarInfo, Long>{
    List<CarInfo> findByMake(String make);

}
