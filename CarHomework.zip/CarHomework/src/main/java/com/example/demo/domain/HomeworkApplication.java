package com.example.demo.domain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoApplication {
    private static final Logger log = LoggerFactory.getLogger(DemoApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(CarRepository repository) {
        return args -> {
            //save a couple car models
            repository.save(new CarInfo(1, 2013, "Nissan", "Altima"));
            repository.save(new CarInfo(2, 2003, "Dodge", "Stratus"));
            repository.save(new CarInfo(3, 1996, "Nissan", "Sentra"));
            repository.save(new CarInfo(4, 2020, "Jeep", "Compass"));

            //read all cars
            log.info("Cars found with findAll() : ");
            log.info("---------------------------------");
            for (CarInfo customer : repository.findAll()) {
                log.info(customer.toString());
            }
            log.info("");

            //read an individual car by ID
            repository.findById(1L)
                    .ifPresent(customer -> {
                        log.info("Customer found with findById(1L) : ");
                        log.info("-----------------------------------");
                        log.info(customer.toString());
                        log.info("");
                    });
            log.info("Customer found with findByLastName('Can't Draft'):");
            log.info("---------------------------------");
            repository.findByMake("Can't Draft").forEach(bauer -> {
                log.info(bauer.toString());
            });
        };
    }
}