package com.example.demo.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

// Lets Spring Boot know that customer classes are an entity stored in db. Also, indicates that customer is jpa entity. Assumed entity will be mapped to a table named customer.
@Entity
public class CarInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int year;
    private Long id;
    private String make, model;

    public CarInfo(Long id, int year, String make, String model) {
        this.year = year;
        this.make = make;
        this.model = model;
        this.id = id;
    }

    // 256 gb @ 719.99
    // 512 gb @ 759.99
    // Typically, you don't need to provide an empty constructor, because Java does it by default.
    private CarInfo(){
        // @Entity needs a no arg constructor
    }
    public String getModel(){
        return model;
    }
    public String getMake(){
        return make;
    }
    public int getYear(){
        return year;
    }
    public Long getId(){
        return id;
    }
    public void setMake(String carMake){
        make = carMake;
    }
    public void setModel(String carModel){
        model = carModel;
    }

    @Override
    public String toString() {
        return "CarInfo{" +
                " id=" + id +
                " year=" + year +
                ", make='" + make + '\'' +
                ", model='" + model + '\'' +
                '}';
    }
}